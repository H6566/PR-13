﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ПР_13.Classes
{
    class Price
    {
        string nameTovar;
        string nameShop;
        double priceTovar;
        int countTovar;

        //свойства
        public string NameProduct
        {
            get { return nameTovar; }
            set { nameTovar = value; }
        }
        public string NameShop
        {
            get { return nameShop; }
            set { nameShop = value; }
        }
        public double PriceProduct
        {
            get { return priceTovar; }
            set { priceTovar = value; }
        }
        public int CountProduct
        {
            get { return countTovar; }
            set { countTovar = value; }
        }
        //конструкторы
        public Price()
        {
            nameTovar = "";
            nameShop = "";
            priceTovar = 0.0;
            countTovar = 0;
        }
        public Price(string name, string nameSh, double price, int count)
        {
            nameTovar = name;
            nameShop = nameSh;
            priceTovar = price;
            countTovar = count;
        }
    }
}

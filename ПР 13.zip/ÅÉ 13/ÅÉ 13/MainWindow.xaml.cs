﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ПР_13.Classes;

namespace ПР_13
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ConnectHelper.prices.Add(new Price("Сухарики", "Пятерочка", 45.70, 46));
            ConnectHelper.prices.Add(new Price("Липтон", "Магнит", 63.30, 170));
            ConnectHelper.prices.Add(new Price("Спраит", "Дикси", 380.20, 90));
            ConnectHelper.prices.Add(new Price("Апельсин", "Магнит", 450.90, 56));
            ConnectHelper.prices.Add(new Price("Чипсы", "FixPrice", 70.60, 90));
            ConnectHelper.prices.Add(new Price("Конфеты", "Пятерочка", 85.78, 9));
            ConnectHelper.prices.Add(new Price("Колбаса", "Магнит", 79.96, 105));
            ConnectHelper.prices.Add(new Price("Килька", "Дикси", 65.35, 15));
            ConnectHelper.prices.Add(new Price("Огурцы", "Лента", 580.38, 72));
            ConnectHelper.prices.Add(new Price("Гречка", "FixPrice", 35.78, 49));
            ConnectHelper.prices.Add(new Price("Печенье Milka", "Spar", 19.45, 8));
            DtgListTovar.ItemsSource = ConnectHelper.prices;
        }

        private void BtnPrint_Click(object sender, RoutedEventArgs e)
        {
            DtgListTovar.ItemsSource = ConnectHelper.prices.ToList();
            DtgListTovar.SelectedIndex = -1;
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DtgListTovar.ItemsSource = ConnectHelper.prices.Where(x =>
                x.NameProduct.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            WindowAdd windowAdd = new WindowAdd();
            windowAdd.ShowDialog();
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            DtgListTovar.ItemsSource = null;
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DtgListTovar.ItemsSource = ConnectHelper.prices.OrderBy(x => x.NameProduct).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DtgListTovar.ItemsSource = ConnectHelper.prices.OrderByDescending(x => x.NameProduct).ToList();
        }

        private void CmbFiltr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            if (CmbFiltr.SelectedIndex == 0)
            {
                DtgListTovar.ItemsSource = ConnectHelper.prices.Where(x =>
                    x.CountProduct >= 0 && x.CountProduct <= 10).ToList();
                MessageBox.Show("Недостаточное количество товара на складе!",
                    "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else
                if (CmbFiltr.SelectedIndex == 1)
            {
                DtgListTovar.ItemsSource = ConnectHelper.prices.Where(x =>
                    x.CountProduct >= 11 && x.CountProduct <= 50).ToList();
                MessageBox.Show("Необходимо пополнить запасы товаров в ближайшее время",
                    "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else
            {
                DtgListTovar.ItemsSource = ConnectHelper.prices.Where(x =>
                   x.CountProduct >= 51).ToList();
                MessageBox.Show("Достаточное количество товара на складе!",
                    "Внимание", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}

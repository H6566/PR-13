﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ПР_13.Classes;

namespace ПР_13
{
    /// <summary>
    /// Логика взаимодействия для WindowAdd.xaml
    /// </summary>
    public partial class WindowAdd : Window
    {
        public WindowAdd()
        {
            InitializeComponent();
        }

        private void BtnAddTovar_Click(object sender, RoutedEventArgs e)
        {
            Price price = new Price()
            {
                NameProduct = TxbName.Text,
                NameShop = Txbshop.Text,
                PriceProduct = double.Parse(TxbPrice.Text),
                CountProduct = int.Parse(TxbCount.Text)
            };
            ConnectHelper.prices.Add(price);
            this.Close();
        }
    }
}
